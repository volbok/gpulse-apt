/* eslint eqeqeq: "off" */
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import moment from 'moment';
import deletar from '../images/deletar.svg';
import salvar from '../images/salvar.svg';
import Toast from './Toast';
import { useHistory } from "react-router-dom";

function Evolucao(
  {
    viewevolucao,
    idpaciente,
    idevolucao,
    data,
    idatendimento,
    idusuario,
    usuario,
    funcao,
    evolucao,
    pas,
    pad,
    fc,
    fr,
    sao2,
    tax,
    diu,
    fezes,
    bh,
    acv,
    ar,
    abdome,
    outros,
    glasgow,
    rass,
    ramsay,
    hd,
    uf,
    heparina,
    braden,
    morse,
  }) {
  //servidor.
  var html = 'https://pulsarapp-server.herokuapp.com';
  let history = useHistory()

  // chave para exibição do componente.
  const [viewcomponent, setviewcomponent] = useState(viewevolucao);

  // variáveis associadas à evolução:
  const [hepa, sethepa] = useState('');
  const [poop, setpoop] = useState('');
  useEffect(() => {
    if (viewevolucao == 1) {
      setviewcomponent(viewevolucao);
      setviewhd(0);
      sethepa(0);
      setpoop('');
    } else if (viewevolucao == 2) {
      setviewcomponent(viewevolucao);
      setpoop(fezes);
      if (hd == 1) {
        setviewhd(1);
        sethepa(heparina);
      } else {
        setviewhd(0);
        sethepa(0);
      }
    }
    // limpando braden e morse.
    setshowbraden(0);
    setnewbraden(braden != '' || braden != '0' ? braden : '?');
    setnewmorse(morse != '' || morse != '0' ? morse : '?');
    setpercepcao(4);
    setumidade(4);
    setatividade(4);
    setmobilidade(4);
    setnutricao(4);
    setfriccao(3)
  }, [viewevolucao])

  // inserindo registro.
  const insertData = () => {
    var evolucao = document.getElementById('inputEvolucao').value.toUpperCase();
    var pas = document.getElementById('inputPas').value.toUpperCase();
    var pad = document.getElementById('inputPad').value.toUpperCase();
    var fc = document.getElementById('inputFc').value.toUpperCase();
    var fr = document.getElementById('inputFr').value.toUpperCase();
    var sao2 = document.getElementById('inputSao2').value.toUpperCase();
    var tax = document.getElementById('inputTax').value.toUpperCase();
    var diu = document.getElementById('inputDiurese').value.toUpperCase();
    var bh = document.getElementById('inputBh').value.toUpperCase();
    // definindo preenchimentos obrigatórios de campos, para médicos e enfermeiros.
    if (funcao < 3 || funcao == 5) {
      if (evolucao != '' && pas != '' && pad != '' && fc != '' && fr != '' && sao2 != '' &&
        tax != '' && diu != '' && poop != '' && bh != '') {
        var obj = {
          idpaciente: idpaciente,
          idatendimento: idatendimento,
          data: moment().format('DD/MM/YY HH:mm'),
          evolucao: evolucao,
          pas: pas,
          pad: pad,
          fc: fc,
          fr: fr,
          sao2: sao2,
          tax: tax,
          diu: diu,
          fezes: poop,
          bh: bh,
          acv: document.getElementById('inputAcv').value,
          ap: document.getElementById('inputAr').value,
          abdome: document.getElementById('inputAbdome').value,
          outros: document.getElementById('inputOutros').value,
          glasgow: document.getElementById('inputGlasgow').value,
          rass: document.getElementById('inputRass').value,
          ramsay: document.getElementById('inputRamsay').value,
          hd: viewhd,
          uf: viewhd === 1 ? document.getElementById('inputUf').value : '',
          heparina: hepa,
          braden: newbraden,
          morse: newmorse,
          status: 0,
          idusuario: idusuario,
          funcao: funcao,
          usuario: usuario,
        };
        axios.post(html + '/insertevolucao', obj);
        toast(1, '#52be80', 'EVOLUÇÃO REGISTRADA COM SUCESSO.', 3000);
        setTimeout(() => {
          setshowbraden(0);
          fechar();
        }, 4000);
      } else {
        toast(1, '#ec7063', 'CAMPOS OBRIGATÓRIOS EM BRANCO.', 3000);
      }
      // definindo obrigação de preenchimento do campo evolução, para demais profissionais.
    } else {
      if (evolucao !== '') {
        var obj = {
          idpaciente: idpaciente,
          idatendimento: idatendimento,
          data: moment().format('DD/MM/YY HH:mm'),
          evolucao: evolucao,
          pas: '',
          pad: '',
          fc: '',
          fr: '',
          sao2: '',
          tax: '',
          diu: '',
          fezes: '',
          bh: '',
          acv: '',
          ap: '',
          abdome: '',
          outros: '',
          glasgow: '',
          rass: '',
          ramsay: '',
          hd: 0,
          uf: 0,
          heparina: 0,
          braden: 0,
          morse: 0,
          status: 0,
          idusuario: idusuario,
          funcao: funcao,
          usuario: usuario,
        };
        axios.post(html + '/insertevolucao', obj);
        toast(1, '#52be80', 'EVOLUÇÃO REGISTRADA COM SUCESSO.', 6000);
        setTimeout(() => {
          setshowbraden(0);
          fechar();
        }, 4000);
      } else {
        toast(1, '#ec7063', 'CAMPO OBRIGATÓRIO EM BRANCO.', 6000);
      }
    }
  };

  // inserindo registro.
  const updateData = () => {
    var evolucao = document.getElementById('inputEvolucao').value.toUpperCase();
    var pas = document.getElementById('inputPas').value.toUpperCase();
    var pad = document.getElementById('inputPad').value.toUpperCase();
    var fc = document.getElementById('inputFc').value.toUpperCase();
    var fr = document.getElementById('inputFr').value.toUpperCase();
    var sao2 = document.getElementById('inputSao2').value.toUpperCase();
    var tax = document.getElementById('inputTax').value.toUpperCase();
    var diu = document.getElementById('inputDiurese').value.toUpperCase();
    var bh = document.getElementById('inputBh').value.toUpperCase();
    if (funcao < 3 || funcao == 5) {
      if (evolucao != '' && pas != '' && pad != '' && fc != '' && fr != '' && sao2 != '' &&
        tax != '' && diu !== '' && poop != '' && bh != '') {
        var obj = {
          idpaciente: idpaciente,
          idatendimento: idatendimento,
          data: data,
          evolucao: evolucao,
          pas: pas,
          pad: pad,
          fc: fc,
          fr: fr,
          sao2: sao2,
          tax: tax,
          diu: diu,
          fezes: poop,
          bh: bh,
          acv: document.getElementById('inputAcv').value,
          ap: document.getElementById('inputAr').value,
          abdome: document.getElementById('inputAbdome').value,
          outros: document.getElementById('inputOutros').value,
          glasgow: document.getElementById('inputGlasgow').value,
          rass: document.getElementById('inputRass').value,
          ramsay: document.getElementById('inputRamsay').value,
          hd: viewhd,
          uf: viewhd === 1 ? document.getElementById('inputUf').value : '',
          heparina: hepa,
          braden: newbraden !== '?' ? newbraden : braden,
          morse: newmorse != '?' ? newmorse : morse,
          status: 0,
          idusuario: idusuario,
          funcao: funcao,
          usuario: usuario,
        };
        axios.post(html + '/updateevolucao/' + idevolucao, obj);
        toast(1, '#52be80', 'EVOLUÇÃO ATUALIZADA COM SUCESSO.', 3000);
        setTimeout(() => {
          setshowbraden(0);
          fechar();
        }, 4000);
      } else {
        toast(1, '#ec7063', 'CAMPOS OBRIGATÓRIOS EM BRANCO.', 3000);
      }
    } else {
      if (evolucao != '') {
        var obj = {
          idpaciente: idpaciente,
          idatendimento: idatendimento,
          data: moment().format('DD/MM/YY HH:mm'),
          evolucao: evolucao,
          pas: '',
          pad: '',
          fc: '',
          fr: '',
          sao2: '',
          tax: '',
          diu: '',
          fezes: '',
          bh: '',
          acv: '',
          ap: '',
          abdome: '',
          outros: '',
          glasgow: '',
          rass: '',
          ramsay: '',
          hd: 0,
          uf: 0,
          heparina: 0,
          braden: 0,
          morse: 0,
          status: 0,
          idusuario: idusuario,
          funcao: funcao,
          usuario: usuario,
        };
        axios.post(html + '/updateevolucao/' + idevolucao, obj);
        toast(1, '#52be80', 'EVOLUÇÃO ATUALIZADA COM SUCESSO.', 6000);
        setTimeout(() => {
          setshowbraden(0);
          fechar();
        }, 4000);
      } else {
        toast(1, '#ec7063', 'CAMPO OBRIGATÓRIO EM BRANCO.', 6000);
      }
    }
  }

  // função para construção dos toasts.
  const [valortoast, setvalortoast] = useState(0);
  const [cor, setcor] = useState('transparent');
  const [mensagem, setmensagem] = useState('');
  const [tempo, settempo] = useState(2000);
  const toast = (value, color, message, time) => {
    setvalortoast(value);
    setcor(color);
    setmensagem(message);
    settempo(time);
    setTimeout(() => {
      setvalortoast(0);
    }, time + 1000);
  }

  // validando entradas para campos numéricos.
  const validateGlasgow = (txt) => {
    var last = txt.slice(-1);
    if (isNaN(last) === true) {
      last = '';
      document.getElementById('inputGlasgow').value = '';
    } else {
    }
  };

  const validateRass = (txt) => {
    var last = txt.slice(-1);
    if (isNaN(last) === true) {
      last = '';
      document.getElementById('inputRass').value = '';
    } else {
    }
  };

  const validateRamsay = (txt) => {
    var last = txt.slice(-1);
    if (isNaN(last) === true) {
      last = '';
      document.getElementById('inputRamsay').value = '';
    } else {
    }
  };

  const validatePas = (txt) => {
    var last = txt.slice(-1);
    if (isNaN(last) === true) {
      last = '';
      document.getElementById('inputPas').value = '';
    } else {
    }
  };
  const validatePad = (txt) => {
    var last = txt.slice(-1);
    if (isNaN(last) === true) {
      last = '';
      document.getElementById('inputPad').value = '';
    } else {
    }
  };
  const validateFc = (txt) => {
    var last = txt.slice(-1);
    if (isNaN(last) === true) {
      last = '';
      document.getElementById('inputFc').value = '';
    } else {
    }
  };
  const validateFr = (txt) => {
    var last = txt.slice(-1);
    if (isNaN(last) === true) {
      last = '';
      document.getElementById('inputFr').value = '';
    } else {
    }
  };
  const validateSao2 = (txt) => {
    var last = txt.slice(-1);
    if (isNaN(last) === true) {
      last = '';
      document.getElementById('inputSao2').value = '';
    } else {
    }
  };
  const validateTax = (txt) => {
    var number = /[0-9]/;
    var dot = /[.]/;
    var last = txt.slice(-1);
    if (last.match(number) !== null || last.match(dot) !== null) {
    } else {
      document.getElementById('inputTax').value = '';
    }
  };
  const validateDiu = (txt) => {
    var last = txt.slice(-1);
    if (isNaN(last) === true) {
      last = '';
      document.getElementById('inputDiurese').value = '';
    } else {
    }
  };
  const validateBh = (txt) => {
    var number = /[0-9]/;
    var sign = /[-]/;
    var last = txt.slice(-1);
    if (last.match(number) !== null || last.match(sign) !== null) {
    } else {
      document.getElementById('inputBh').value = '';
    }
  };
  const validateUf = (txt) => {
    var number = /[0-9]/;
    var last = txt.slice(-1);
    if (last.match(number) !== null) {
      setultrafiltrado(txt);
      setTimeout(() => {
        document.getElementById('inputUf').focus();
      }, 100);
    } else {
      document.getElementById('inputUf').value = '';
    }
  };

  const [viewhd, setviewhd] = useState(0);
  function Hemodialise() {
    if (viewhd === 1) {
      return (
        <div
          style={{
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'center',
            marginTop: 5
          }}>
          <input
            className="input"
            autoComplete="off"
            placeholder="UF"
            title="ULTRAFILTRADO (PERDAS EM ML)."
            defaultValue={ultrafiltrado}
            onFocus={(e) => (e.target.placeholder = '')}
            onBlur={(e) => (e.target.placeholder = 'UF')}
            onChange={(e) => validateUf(e.target.value)}
            style={{
              height: 50,
              width: window.innerWidth > 800 ? 100 : 50,
              margin: 0,
              padding: 0,
            }}
            id="inputUf"
            maxLength={4}
          ></input>
          <button
            className={hepa === 1 ? "red-button" : "blue-button"}
            title="USO DE HEPARINA NA DIÁLISE."
            defaultValue={hepa}
            onClick={() => changeUf()}
            style={{
              padding: 10,
              margin: 0,
              marginLeft: 10,
              width: 100,
              height: 50,
              backgroundColor: hepa === 1 ? '#ec7063' : '#1f7a8c'
            }}
          >
            HEPARINA
          </button>
        </div>
      )
    } else {
      return null;
    }
  }

  const [ultrafiltrado, setultrafiltrado] = useState(0);
  const changeUf = () => {
    setultrafiltrado(document.getElementById("inputUf").value)
    if (hepa == 0) {
      sethepa(1);
    } else {
      sethepa(0);
    }
  }

  // CLASSIFICAÇÃO DE BRADEN.
  const [percepcao, setpercepcao] = useState(4);
  const [umidade, setumidade] = useState(4);
  const [atividade, setatividade] = useState(4);
  const [mobilidade, setmobilidade] = useState(4);
  const [nutricao, setnutricao] = useState(4);
  const [friccao, setfriccao] = useState(3);

  const [newbraden, setnewbraden] = useState(braden);
  const setBraden = () => {
    setnewbraden(percepcao + umidade + atividade + mobilidade + nutricao + friccao);
    setshowbraden(0);
  }

  const [showbraden, setshowbraden] = useState(0);
  function Braden() {
    if (showbraden === 1) {
      return (
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', backgroundColor: '#ffffff', padding: 5, borderRadius: 10, margin: 10 }}>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', marginBottom: 5 }}>
            <div className="title2" style={{ fontSize: 14, width: 150, textAlign: 'center' }}>PERCEPÇÃO SENSORIAL:</div>
            <button
              onClick={() => { setpercepcao(1) }}
              className={percepcao === 1 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              TOTALMENTE LIMITADO
            </button>
            <button
              onClick={() => { setpercepcao(2) }}
              className={percepcao === 2 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              MUITO LIMITADO
            </button>
            <button
              onClick={() => { setpercepcao(3) }}
              className={percepcao === 3 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              LEVEMENTE LIMITADO
            </button>
            <button
              onClick={() => { setpercepcao(4) }}
              className={percepcao === 4 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              NENHUMA LIMITAÇÃO
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', marginBottom: 5 }}>
            <div className="title2" style={{ fontSize: 14, width: 150, textAlign: 'center' }}>UMIDADE:</div>
            <button
              onClick={() => { setumidade(1) }}
              className={umidade === 1 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              COMPLETAMENTE MOLHADO
            </button>
            <button
              onClick={() => { setumidade(2) }}
              className={umidade === 2 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              MUITO MOLHADO
            </button>
            <button
              onClick={() => { setumidade(3) }}
              className={umidade === 3 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              OCASIONALMENTE MOLHADO
            </button>
            <button
              onClick={() => { setumidade(4) }}
              className={umidade === 4 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              RARAMENTE MOLHADO
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', marginBottom: 5 }}>
            <div className="title2" style={{ fontSize: 14, width: 150, textAlign: 'center' }}>ATIVIDADE:</div>
            <button
              onClick={() => { setatividade(1) }}
              className={atividade === 1 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              ACAMADO
            </button>
            <button
              onClick={() => { setatividade(2) }}
              className={atividade === 2 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              CONFINADO À CADEIRA
            </button>
            <button
              onClick={() => { setatividade(3) }}
              className={atividade === 3 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              ANDA OCASIONALMENTE
            </button>
            <button
              onClick={() => { setatividade(4) }}
              className={atividade === 4 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              ANDA FREQUENTEMENTE
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', marginBottom: 5 }}>
            <div className="title2" style={{ fontSize: 14, width: 150, textAlign: 'center' }}>MOBILIDADE:</div>
            <button
              onClick={() => { setmobilidade(1) }}
              className={mobilidade === 1 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              TOTALMENTE LIMITADO
            </button>
            <button
              onClick={() => { setmobilidade(2) }}
              className={mobilidade === 2 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              BASTANTE LIMITADO
            </button>
            <button
              onClick={() => { setmobilidade(3) }}
              className={mobilidade === 3 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              LEVEMENTE LIMITADO
            </button>
            <button
              onClick={() => { setmobilidade(4) }}
              className={mobilidade === 4 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              NÃO APRESENTA LIMITAÇÕES
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', marginBottom: 5 }}>
            <div className="title2" style={{ fontSize: 14, width: 150, textAlign: 'center' }}>NUTRIÇÃO:</div>
            <button
              onClick={() => { setnutricao(1) }}
              className={nutricao === 1 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              MUITO POBRE
            </button>
            <button
              onClick={() => { setnutricao(2) }}
              className={nutricao === 2 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              PROVAVELMENTE INADEQUADA
            </button>
            <button
              onClick={() => { setnutricao(3) }}
              className={nutricao === 3 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              ADEQUADA
            </button>
            <button
              onClick={() => { setnutricao(4) }}
              className={nutricao === 4 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              EXCELENTE
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', marginBottom: 5 }}>
            <div className="title2" style={{ fontSize: 14, width: 150, textAlign: 'center' }}>FRICÇÃO E CISALHAMENTO:</div>
            <button
              onClick={() => { setfriccao(1) }}
              className={friccao === 1 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              PROBLEMA
            </button>
            <button
              onClick={() => { setfriccao(2) }}
              className={friccao === 2 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              PROBLEMA POTENCIAL
            </button>
            <button
              onClick={() => { setfriccao(3) }}
              className={friccao === 3 ? "red-button" : "blue-button"}
              style={{ width: 150 }}>
              NENHUM PROBLEMA
            </button>
            <button className="blue-button" disabled="true" style={{ width: 150, opacity: 0.5 }}></button>
          </div>
          <button
            onClick={() => { setBraden() }}
            className="green-button"
            style={{ width: 150, alignSelf: 'center' }}>
            CONCLUÍDO
          </button>
        </div>
      );
    } else {
      return null;
    }
  }

  // CLASSIFICAÇÃO DE MORSE.
  const [quedas, setquedas] = useState(0);
  const [diagsec, setdiagsec] = useState(0);
  const [auxilio, setauxilio] = useState(0);
  const [endovenosa, setendovenosa] = useState(0);
  const [marcha, setmarcha] = useState(0);
  const [mental, setmental] = useState(0);

  const [newmorse, setnewmorse] = useState(morse);
  const setMorse = () => {
    setnewmorse(quedas + diagsec + auxilio + endovenosa + marcha + mental);
    setshowmorse(0);
  }

  const [showmorse, setshowmorse] = useState(0);
  function Morse() {
    if (showmorse === 1) {
      return (
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'left', backgroundColor: '#ffffff', padding: 5, borderRadius: 10, margin: 10 }}>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'left', marginBottom: 5 }}>
            <div className="title2" style={{ fontSize: 14, width: 150, textAlign: 'center' }}>HISTÓRICO DE QUEDAS:</div>
            <button
              onClick={() => { setquedas(0) }}
              className={quedas === 0 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              NÃO
            </button>
            <button
              onClick={() => { setquedas(25) }}
              className={quedas === 25 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              SIM
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'left', marginBottom: 5 }}>
            <div className="title2" style={{ fontSize: 14, width: 150, textAlign: 'center' }}>DIAGNÓSTICO SECUNDÁRIO:</div>
            <button
              onClick={() => { setdiagsec(0) }}
              className={diagsec === 0 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              NÃO
            </button>
            <button
              onClick={() => { setdiagsec(15) }}
              className={diagsec === 15 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              SIM
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'left', marginBottom: 5 }}>
            <div className="title2" style={{ fontSize: 14, width: 150, textAlign: 'center' }}>AUXÍLIO NA DEAMBULAÇÃO:</div>
            <button
              onClick={() => { setauxilio(0) }}
              className={auxilio === 0 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              NENHUM, ACAMADO OU AUXILIADO POR PROFISSIONAL DE SAÚDE
            </button>
            <button
              onClick={() => { setauxilio(15) }}
              className={auxilio === 15 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              MULETAS, BENGALA OU ANDADOR
            </button>
            <button
              onClick={() => { setauxilio(30) }}
              className={auxilio === 30 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              MOBILIÁRIO OU PAREDE
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'left', marginBottom: 5 }}>
            <div className="title2" style={{ fontSize: 14, width: 150, textAlign: 'center' }}>TERAPIA ENDOVENOSA OU CATETER VENOSO:</div>
            <button
              onClick={() => { setendovenosa(0) }}
              className={endovenosa === 0 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              NÃO
            </button>
            <button
              onClick={() => { setendovenosa(20) }}
              className={endovenosa === 20 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              SIM
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'left', marginBottom: 5 }}>
            <div className="title2" style={{ fontSize: 14, width: 150, textAlign: 'center' }}>MARCHA:</div>
            <button
              onClick={() => { setmarcha(0) }}
              className={marcha === 0 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              NORMAL, CADEIRANTE OU ACAMADO
            </button>
            <button
              onClick={() => { setmarcha(10) }}
              className={marcha === 10 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              FRACA
            </button>
            <button
              onClick={() => { setmarcha(20) }}
              className={marcha === 20 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              COMPROMETIDA, CAMBALEANTE
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'left', marginBottom: 5 }}>
            <div className="title2" style={{ fontSize: 14, width: 150, textAlign: 'center' }}>ESTADO MENTAL:</div>
            <button
              onClick={() => { setmental(0) }}
              className={mental === 0 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              ORIENTADO E CAPAZ QUANTO A SUA LIMITAÇÃO
            </button>
            <button
              onClick={() => { setmental(15) }}
              className={mental === 15 ? "red-button" : "blue-button"}
              style={{ width: 150, padding: 10 }}>
              SUPERESTIMA CAPACIDADES E ESQUECE LIMITAÇÕES
            </button>
          </div>
          <button
            onClick={() => { setMorse() }}
            className="green-button"
            style={{ width: 150, alignSelf: 'center' }}>
            CONCLUÍDO
          </button>
        </div>
      );
    } else {
      return null;
    }
  }

  const fechar = () => {
    setviewcomponent(0);
    window.scrollTo(0, 0);
    document.body.style.overflow = null;
    history.push('/refresh')
    history.push('/prontuario')
  }

  // renderização do componente.
  if (viewcomponent === 1) { // inserir.
    return (
      <div
        className="menucover fade-in" style={{ zIndex: 9, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
        <Toast valortoast={valortoast} cor={cor} mensagem={mensagem} tempo={tempo} />
        <div className="menucontainer" id="MENUCONTAINER">
          <label className="title2" style={{ marginTop: 0, fontSize: 16, marginBottom: 25 }}>
            INSERIR EVOLUÇÃO
          </label>
          <div
            className="scroll"
            style={{
              justifyContent: 'flex-start',
              backgroundColor: '#F1F3F9',
              borderColor: '#F1F3F9',
              margin: 0,
              height: 400,
              paddingRight: 5,
            }}
          >
            <label className="title2" style={{ marginTop: 15, fontSize: 14 }}>
              EVOLUÇÃO:
            </label>
            <textarea
              autoComplete="off"
              className="textarea"
              placeholder="EVOLUÇÃO."
              onFocus={(e) => (e.target.placeholder = '')}
              onBlur={(e) => (e.target.placeholder = 'EVOLUÇÃO.')}
              title="EVOLUÇÃO."
              style={{
                width: window.innerWidth > 800 ? 0.4 * window.innerWidth : 250,
                minHeight: funcao < 3 || funcao == 5 ? 125 : 290,
              }}
              type="text"
              maxLength={200}
              id="inputEvolucao"
            ></textarea>
            <label className="title2" style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', marginTop: 15, fontSize: 14 }}>
              SENSÓRIO:
            </label>
            <div style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', flexDirection: 'row' }}>
              <input
                className="input"
                autoComplete="off"
                placeholder="GLASGOW"
                title="GLASGOW"
                onFocus={(e) => (e.target.placeholder = '')}
                onBlur={(e) => (e.target.placeholder = 'GLASGOW')}
                onChange={(e) => validateGlasgow(e.target.value)}
                style={{
                  minHeight: 50,
                  width: window.innerWidth > 800 ? 100 : 50,
                  textAlign: 'center',
                }}
                min={3}
                max={15}
                id="inputGlasgow"
                maxLength={2}
                type="float"
              ></input>
              <input
                className="input"
                autoComplete="off"
                placeholder="RASS"
                title="RASS"
                onFocus={(e) => (e.target.placeholder = '')}
                onBlur={(e) => (e.target.placeholder = 'RASS')}
                onChange={(e) => validateGlasgow(e.target.value)}
                style={{
                  minHeight: 50,
                  width: window.innerWidth > 800 ? 100 : 50,
                  textAlign: 'center',
                }}
                min={-5}
                max={4}
                id="inputRass"
                type="float"
                maxLength={2}
              ></input>
              <input
                className="input"
                autoComplete="off"
                placeholder="RAMSAY"
                title="RAMSAY"
                onFocus={(e) => (e.target.placeholder = '')}
                onBlur={(e) => (e.target.placeholder = 'RAMSAY')}
                onChange={(e) => validateRamsay(e.target.value)}
                style={{
                  minHeight: 50,
                  width: window.innerWidth > 800 ? 100 : 50,
                  textAlign: 'center',
                }}
                min={1}
                max={6}
                id="inputRamsay"
                type="float"
                maxLength={1}
              ></input>
            </div>
            <div id="BRADEN E MORSE" style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', flexDirection: 'column', justifyContent: 'center' }}>
              <div style={{ display: window.innerWidth > 800 ? 'flex' : 'none', flexDirection: 'column', justifyContent: 'center' }}>
                <label className="title2" style={{ marginTop: 15, fontSize: 14 }}> BRADEN:</label>
                <button
                  className={showbraden === 1 ? "red-button" : "blue-button"}
                  onClick={() => setshowbraden(1)}
                  style={{
                    display: window.innerWidth < 400 || showbraden === 1 ? 'none' : 'flex',
                    padding: 10,
                    width: 300,
                    alignSelf: 'center',
                  }}
                >
                  {newbraden > 14 ? 'BRADEN: ' + newbraden + ' - RISCO BAIXO' : newbraden > 12 && newbraden < 15 ? 'BRADEN: ' + newbraden + ' - RISCO MODERADO' : newbraden > 9 && newbraden < 13 ? 'BRADEN: ' + newbraden + ' - RISCO ALTO' : newbraden < 10 ? 'BRADEN: ' + newbraden + ' - RISCO MUITO ALTO' : 'BRADEN ?'}
                </button>
              </div>
              <div style={{ display: window.innerWidth > 400 && (funcao < 3 || funcao == 5) ? 'flex' : 'none', flexDirection: 'row', justifyContent: 'center' }}>
                <Braden></Braden>
              </div>
              <div style={{ display: window.innerWidth > 400 ? 'flex' : 'none', flexDirection: 'column', justifyContent: 'center' }}>
                <label className="title2" style={{ marginTop: 15, fontSize: 14 }}> MORSE:</label>
                <button
                  className={showmorse === 1 ? "red-button" : "blue-button"}
                  onClick={() => setshowmorse(1)}
                  style={{
                    display: window.innerWidth < 400 || showmorse === 1 ? 'none' : 'flex',
                    padding: 10,
                    width: 300,
                    alignSelf: 'center',
                  }}
                >
                  {newmorse < 41 ? 'MORSE: ' + newmorse + ' - RISCO MÉDIO' : newmorse > 40 && newmorse < 52 ? 'MORSE: ' + newmorse + ' - RISCO ELEVADO' : newmorse > 51 ? 'MORSE: ' + newmorse + ' - RISCO MUITO ELEVADO' : 'MORSE ?'}
                </button>
              </div>
              <div style={{ display: window.innerWidth > 400 && (funcao < 3 || funcao == 5) ? 'flex' : 'none', flexDirection: 'row', justifyContent: 'center' }}>
                <Morse></Morse>
              </div>
            </div>
            <div id="PA, FC, FR"
              style={{
                display: funcao < 3 || funcao == 5 ? 'flex' : 'none',
                flexDirection: 'row',
              }}
            >
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  PAS:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="PAS"
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'PAS')}
                  onChange={(e) => validatePas(e.target.value)}
                  title="PRESSÃO ARTERIAL SISTÓLICA."
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                    marginLeft: 0,
                  }}
                  id="inputPas"
                  maxLength={3}
                ></input>
              </div>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  PAD:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="PAD"
                  title="PRESSÃO ARTERIAL DIASTÓLICA."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'PAD')}
                  onChange={(e) => validatePad(e.target.value)}
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                    marginLeft: 5,
                  }}
                  id="inputPad"
                  maxLength={3}
                ></input>
              </div>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  FC:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="FC"
                  title="FREQUÊNCIA CARDÍACA."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'FC')}
                  onChange={(e) => validateFc(e.target.value)}
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                    marginLeft: 5,
                  }}
                  id="inputFc"
                  maxLength={3}
                ></input>
              </div>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  FR:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="FR"
                  title="FREQUÊNCIA RESPIRATÓRIA."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'FR')}
                  onChange={(e) => validateFr(e.target.value)}
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                    marginLeft: 5,
                  }}
                  id="inputFr"
                  maxLength={2}
                ></input>
              </div>
            </div>
            <div id="TAX, SAO2" style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', flexDirection: 'row', marginTop: 5 }}>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  TAX:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="TAX"
                  title="TEMPERATURA AXILAR."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'TAX')}
                  onChange={(e) => validateTax(e.target.value)}
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                    marginLeft: 0,
                  }}
                  id="inputTax"
                  maxLength={4}
                ></input>
              </div>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  SAO2:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="SAO2"
                  title="SAO2."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'SAO2')}
                  onChange={(e) => validateSao2(e.target.value)}
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                    marginLeft: 5,
                  }}
                  id="inputSao2"
                  min={0}
                  max={100}
                ></input>
              </div>
            </div>
            <div id="EVACUAÇÕES"
              style={{
                display: funcao < 3 || funcao == 5 || funcao == 4 ? 'flex' : 'none', // médico, chefe, enfermeira ou técnico de enfermagem.
                flexDirection: 'column',
                borderRadius: 5,
                marginTop: 5,
                marginBottom: 0,
              }}
            >
              <label className="title2" style={{ marginTop: 15, fontSize: 14 }}>
                EVACUAÇÕES:
              </label>
              <div style={{ display: 'flex', flexDirection: 'row' }}>
                <button
                  className="blue-button"
                  onClick={() => setpoop('AUSENTES')}
                  style={{
                    padding: 10,
                    marginTop: 5,
                    marginRight: 10,
                    width: window.innerWidth > 800 ? 100 : 75,
                    backgroundColor: poop === 'AUSENTES' ? '#ec7063' : '#1f7a8c',
                  }}
                >
                  AUSENTES
                </button>
                <button
                  className="blue-button"
                  onClick={() => setpoop('NORMAIS')}
                  style={{
                    padding: 10,
                    marginTop: 5,
                    marginRight: 10,
                    width: window.innerWidth > 800 ? 100 : 75,
                    backgroundColor: poop === 'NORMAIS' ? '#ec7063' : '#1f7a8c',
                  }}
                >
                  NORMAIS
                </button>
                <button
                  className="blue-button"
                  onClick={() => setpoop('DIARRÉIA')}
                  style={{
                    padding: 10,
                    marginTop: 5,
                    marginRight: 10,
                    width: window.innerWidth > 800 ? 100 : 75,
                    backgroundColor: poop === 'DIARRÉIA' ? '#ec7063' : '#1f7a8c',
                  }}
                >
                  DIARRÉIA
                </button>
              </div>
            </div>
            <div id="DIURESE E BH"
              style={{
                display: funcao < 3 || funcao == 5 || funcao == 4 ? 'flex' : 'none', flexDirection: 'row' // médico, chefe, enfermeira ou técnico de enfermagem.
              }}>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  DIURESE:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="DIURESE"
                  title="DIURESE."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'DIURESE')}
                  onChange={(e) => validateDiu(e.target.value)}
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                  }}
                  id="inputDiurese"
                  maxLength={4}
                ></input>
              </div>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  BH:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="BH"
                  title="BALANÇO HÍDRICO."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'BH')}
                  onChange={(e) => validateBh(e.target.value)}
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                    marginLeft: 5,
                  }}
                  id="inputBh"
                  maxLength={5}
                ></input>
              </div>
            </div>
            <div id="HD" style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', flexDirection: 'row', justifyContent: 'center', marginTop: 15 }}>
              <button
                className="blue-button"
                onClick={() => viewhd === 1 ? setviewhd(0) : setviewhd(1)}
                title="HEMODIÁLISE."
                style={{
                  padding: 10,
                  marginTop: 5,
                  marginRight: viewhd === 1 ? 10 : 0,
                  backgroundColor: viewhd === 1 ? '#ec7063' : '#1f7a8c',
                }}
              >
                HD
              </button>
              <Hemodialise></Hemodialise>
            </div>
            <div id="ACV E AP" style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', flexDirection: 'row' }}>
              <div>
                <label
                  className="title2"
                  style={{
                    marginTop: 15,
                    fontSize: 14,
                    justifyContent: 'center',
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                  }}
                >
                  {window.innerWidth > 800 ? 'APARELHO CARDIOVASCULAR:' : 'ACV:'}
                </label>
                <textarea
                  className="textarea"
                  autoComplete="off"
                  placeholder="APARELHO CARDIOVASCULAR."
                  title="APARELHO CARDIOVASCULAR."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'ACV.')}
                  style={{
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                    height: 80,
                    marginRight: window.innerWidth > 800 ? 10 : 2.5,
                  }}
                  type="text"
                  id="inputAcv"
                  maxLength={50}
                ></textarea>
              </div>
              <div>
                <label
                  className="title2"
                  style={{
                    marginTop: 15,
                    fontSize: 14,
                    justifyContent: 'center',
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                  }}
                >
                  {window.innerWidth > 800 ? 'APARELHO RESPIRATÓRIO:' : 'AR:'}
                </label>
                <textarea
                  className="textarea"
                  autoComplete="off"
                  placeholder="APARELHO RESPIRATÓRIO."
                  title="APARELHO RESPIRATÓRIO."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'AR.')}
                  style={{
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                    height: 80,
                  }}
                  type="text"
                  id="inputAr"
                  maxLength={50}
                ></textarea>
              </div>
            </div>
            <div id="ABDOME E OUTROS" style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', flexDirection: 'row', marginBottom: 5 }}>
              <div>
                <label
                  className="title2"
                  style={{
                    marginTop: 15,
                    fontSize: 14,
                    justifyContent: 'center',
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                  }}
                >
                  ABDOME:
                </label>
                <textarea
                  className="textarea"
                  autoComplete="off"
                  placeholder="ABDOME."
                  title="ABDOME."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'ABDOME.')}
                  style={{
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                    height: 80,
                    marginRight: window.innerWidth > 800 ? 10 : 2.5,
                  }}
                  type="text"
                  id="inputAbdome"
                  maxLength={50}
                ></textarea>
              </div>
              <div>
                <label
                  className="title2"
                  style={{
                    marginTop: 15,
                    fontSize: 14,
                    justifyContent: 'center',
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                  }}
                >
                  OUTROS:
                </label>
                <textarea
                  className="textarea"
                  autoComplete="off"
                  placeholder="OUTROS."
                  title="OUTROS DADOS CLÍNICOS IMPORTANTES."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'OUTROS.')}
                  style={{
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                    height: 80,
                  }}
                  type="text"
                  id="inputOutros"
                  maxLength={50}
                ></textarea>
              </div>
            </div>
          </div>
          <div
            style={{
              display: 'flex',
              flexDirection: 'row',
              marginTop: 25,
              marginBottom: 0,
            }}
          >
            <button className="red-button" onClick={() => setviewcomponent(0)}>
              <img
                alt=""
                src={deletar}
                style={{
                  margin: 10,
                  height: 30,
                  width: 30,
                }}
              ></img>
            </button>
            <button className="green-button"
              onClick={() => insertData()}
              onMouseOver={() => poop == '' ? toast(1, '#ec7063', 'FAVOR INFORMAR EVACUAÇÃO.', 3000) : null}>
              <img
                alt=""
                src={salvar}
                style={{
                  margin: 10,
                  height: 30,
                  width: 30,
                }}
              ></img>
            </button>
          </div>
        </div>
      </div>
    );
  } else if (viewcomponent === 2) { // atualizar.
    return (
      <div className="menucover fade-in" style={{ zIndex: 9, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
        <Toast valortoast={valortoast} cor={cor} mensagem={mensagem} tempo={tempo} />
        <div className="menucontainer">
          <label className="title2" style={{ marginTop: 0, fontSize: 16, marginBottom: 25 }}>
            ATUALIZAR EVOLUÇÃO
          </label>
          <div
            className="scroll"
            style={{
              justifyContent: 'flex-start',
              backgroundColor: '#F1F3F9',
              borderColor: '#F1F3F9',
              height: 350,
              margin: 0,
              paddingRight: 5,
            }}
          >
            <label className="title2" style={{ marginTop: 15, fontSize: 14 }}>
              EVOLUÇÃO:
            </label>
            <textarea
              autoComplete="off"
              className="textarea"
              placeholder="EVOLUÇÃO."
              onFocus={(e) => (e.target.placeholder = '')}
              onBlur={(e) => (e.target.placeholder = 'EVOLUÇÃO.')}
              defaultValue={evolucao}
              title="EVOLUÇÃO."
              style={{
                width: window.innerWidth > 800 ? 0.4 * window.innerWidth : 250,
                minHeight: funcao < 3 || funcao == 5 ? 125 : 290,
              }}
              type="text"
              maxLength={200}
              id="inputEvolucao"
            ></textarea>
            <label className="title2" style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', marginTop: 15, fontSize: 14 }}>
              SENSÓRIO:
            </label>
            <div style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', flexDirection: 'row' }}>
              <input
                className="input"
                autoComplete="off"
                placeholder="GLASGOW"
                title="GLASGOW"
                defaultValue={glasgow}
                onFocus={(e) => (e.target.placeholder = '')}
                onBlur={(e) => (e.target.placeholder = 'GLASGOW')}
                onChange={(e) => validateGlasgow(e.target.value)}
                style={{
                  minHeight: 50,
                  width: window.innerWidth > 800 ? 100 : 50,
                  textAlign: 'center',
                }}
                min={3}
                max={15}
                id="inputGlasgow"
                maxLength={2}
                type="number"
              ></input>
              <input
                className="input"
                autoComplete="off"
                placeholder="RASS"
                title="RASS"
                defaultValue={rass}
                onFocus={(e) => (e.target.placeholder = '')}
                onBlur={(e) => (e.target.placeholder = 'RASS')}
                onChange={(e) => validateRass(e.target.value)}
                style={{
                  minHeight: 50,
                  width: window.innerWidth > 800 ? 100 : 50,
                  textAlign: 'center',
                }}
                min={-5}
                max={4}
                id="inputRass"
                type="float"
                maxLength={2}
              ></input>
              <input
                className="input"
                autoComplete="off"
                placeholder="RAMSAY"
                title="RAMSAY"
                defaultValue={ramsay}
                onFocus={(e) => (e.target.placeholder = '')}
                onBlur={(e) => (e.target.placeholder = 'RAMSAY')}
                onChange={(e) => validateRamsay(e.target.value)}
                style={{
                  minHeight: 50,
                  width: window.innerWidth > 800 ? 100 : 50,
                  textAlign: 'center',
                }}
                min={1}
                max={6}
                id="inputRamsay"
                type="float"
                maxLength={1}
              ></input>
            </div>
            <div id="BRADEN E MORSE" style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', flexDirection: 'column', justifyContent: 'center' }}>
              <div style={{ display: window.innerWidth > 800 ? 'flex' : 'none', flexDirection: 'column', justifyContent: 'center' }}>
                <label className="title2" style={{ marginTop: 15, fontSize: 14 }}> BRADEN:</label>
                <button
                  className={showbraden === 1 ? "red-button" : "blue-button"}
                  onClick={() => setshowbraden(1)}
                  style={{
                    display: showbraden === 1 ? 'none' : 'flex',
                    padding: 10,
                    width: window.innerWidth > 800 ? 300 : 50,
                    alignSelf: 'center',
                  }}
                >
                  {newbraden > 14 ? 'BRADEN: ' + newbraden + ' - RISCO BAIXO' : newbraden > 12 && newbraden < 15 ? 'BRADEN: ' + newbraden + ' - RISCO MODERADO' : newbraden > 9 && newbraden < 13 ? 'BRADEN: ' + newbraden + ' - RISCO ALTO' : newbraden < 10 ? 'BRADEN: ' + newbraden + ' - RISCO MUITO ALTO' : 'BRADEN ?'}
                </button>
              </div>
              <div style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', flexDirection: 'row', justifyContent: 'center' }}>
                <Braden></Braden>
              </div>
              <div style={{ display: window.innerWidth > 800 ? 'flex' : 'none', flexDirection: 'column', justifyContent: 'center' }}>
                <label className="title2" style={{ marginTop: 15, fontSize: 14 }}> MORSE:</label>
                <button
                  className={showmorse === 1 ? "red-button" : "blue-button"}
                  onClick={() => setshowmorse(1)}
                  style={{
                    display: showmorse === 1 ? 'none' : 'flex',
                    padding: 10,
                    width: window.innerWidth > 800 ? 300 : 50,
                    alignSelf: 'center',
                  }}
                >
                  {newmorse < 41 ? 'MORSE: ' + newmorse + ' - RISCO MÉDIO' : newmorse > 40 && newmorse < 52 ? 'MORSE: ' + newmorse + ' - RISCO ELEVADO' : newmorse > 51 ? 'MORSE: ' + newmorse + ' - RISCO MUITO ELEVADO' : 'MORSE ?'}
                </button>
              </div>
              <div style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', flexDirection: 'row', justifyContent: 'center' }}>
                <Morse></Morse>
              </div>
            </div>
            <div id="PA, FC, FR"
              style={{
                display: funcao < 3 || funcao == 5 ? 'flex' : 'none',
                flexDirection: 'row',
              }}
            >
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  PAS:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="PAS"
                  defaultValue={pas}
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'PAS')}
                  onChange={(e) => validatePas(e.target.value)}
                  title="PRESSÃO ARTERIAL SISTÓLICA."
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                    marginLeft: 0,
                  }}
                  id="inputPas"
                  maxLength={3}
                ></input>
              </div>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  PAD:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="PAD"
                  defaultValue={pad}
                  title="PRESSÃO ARTERIAL DIASTÓLICA."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'PAD')}
                  onChange={(e) => validatePad(e.target.value)}
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                    marginLeft: 5,
                  }}
                  id="inputPad"
                  maxLength={3}
                ></input>
              </div>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  FC:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="FC"
                  defaultValue={fc}
                  title="FREQUÊNCIA CARDÍACA."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'FC')}
                  onChange={(e) => validateFc(e.target.value)}
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                    marginLeft: 5,
                  }}
                  id="inputFc"
                  maxLength={3}
                ></input>
              </div>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  FR:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="FR"
                  defaultValue={fr}
                  title="FREQUÊNCIA RESPIRATÓRIA."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'FR')}
                  onChange={(e) => validateFr(e.target.value)}
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                    marginLeft: 5,
                  }}
                  id="inputFr"
                  maxLength={2}
                ></input>
              </div>
            </div>
            <div id="TAX E SAO2"
              style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', flexDirection: 'row', marginTop: 5 }}>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  TAX:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="TAX"
                  title="TEMPERATURA AXILAR."
                  defaultValue={tax}
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'TAX')}
                  onChange={(e) => validateTax(e.target.value)}
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                    marginLeft: 0,
                  }}
                  id="inputTax"
                  maxLength={4}
                ></input>
              </div>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  SAO2:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="SAO2"
                  title="SAO2."
                  defaultValue={sao2}
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'SAO2')}
                  onChange={(e) => validateSao2(e.target.value)}
                  style={{
                    height: 50,
                    width: window.innerWidth > 800 ? 100 : 50,
                    marginBottom: 0,
                    marginLeft: 5,
                  }}
                  id="inputSao2"
                  min={0}
                  max={100}
                ></input>
              </div>
            </div>
            <div id="EVACUAÇÕES"
              style={{
                display: funcao < 3 || funcao == 5 || funcao == 4 ? 'flex' : 'none', // chefe, médico, enfermeira ou técnico de enfermagem.
                flexDirection: 'column',
                borderRadius: 5,
                marginTop: 5,
                marginBottom: 0,
              }}
            >
              <label className="title2" style={{ marginTop: 15, fontSize: 14 }}>
                EVACUAÇÕES:
              </label>
              <div style={{ display: 'flex', flexDirection: 'row' }}>
                <button
                  className="blue-button"
                  onClick={() => setpoop('AUSENTES')}
                  style={{
                    padding: 10,
                    marginTop: 5,
                    marginRight: 10,
                    width: window.innerWidth > 800 ? 100 : 75,
                    backgroundColor: poop === 'AUSENTES' ? '#ec7063' : '#1f7a8c',
                  }}
                >
                  AUSENTES
                </button>
                <button
                  className="blue-button"
                  onClick={() => setpoop('NORMAIS')}
                  style={{
                    padding: 10,
                    marginTop: 5,
                    marginRight: 10,
                    width: window.innerWidth > 800 ? 100 : 75,
                    backgroundColor: poop === 'NORMAIS' ? '#ec7063' : '#1f7a8c',
                  }}
                >
                  NORMAIS
                </button>
                <button
                  className="blue-button"
                  onClick={() => setpoop('DIARRÉIA')}
                  style={{
                    padding: 10,
                    marginTop: 5,
                    marginRight: 10,
                    width: window.innerWidth > 800 ? 100 : 75,
                    backgroundColor: poop === 'DIARRÉIA' ? '#ec7063' : '#1f7a8c',
                  }}
                >
                  DIARRÉIA
                </button>
              </div>
            </div>
            <div id="DIURESE"
              style={{
                display: funcao < 3 || funcao == 5 || funcao == 4 ? 'flex' : 'none', flexDirection: 'row' // chefe, médico, enfermeira e técnico de enfermagem.
              }}>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  DIURESE:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="DIURESE"
                  title="DIURESE."
                  defaultValue={diu}
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'DIURESE')}
                  onChange={(e) => validateDiu(e.target.value)}
                  style={{
                    height: 50,
                    width: 100,
                    marginBottom: 0,
                  }}
                  id="inputDiurese"
                  maxLength={4}
                ></input>
              </div>
              <div>
                <label
                  className="title2"
                  style={{ marginTop: 15, fontSize: 14 }}
                >
                  BH:
                </label>
                <input
                  className="input"
                  autoComplete="off"
                  placeholder="BH"
                  title="BALANÇO HÍDRICO."
                  defaultValue={bh}
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'BH')}
                  onChange={(e) => validateBh(e.target.value)}
                  style={{
                    height: 50,
                    width: 100,
                    marginBottom: 0,
                    marginLeft: 5,
                  }}
                  id="inputBh"
                  maxLength={5}
                ></input>
              </div>
            </div>
            <div id="HD"
              style={{ display: funcao < 3 || funcao == 5 ? 'flex' : 'none', flexDirection: 'row', justifyContent: 'center', marginTop: 15 }}>
              <button
                className="blue-button"
                onClick={() => viewhd === 1 ? setviewhd(0) : setviewhd(1)}
                title="HEMODIÁLISE."
                style={{
                  display: funcao < 3 || funcao == 5 ? 'flex' : 'none',
                  padding: 10,
                  marginTop: 5,
                  marginRight: viewhd === 1 ? 10 : 0,
                  backgroundColor: viewhd === 1 ? '#ec7063' : '#1f7a8c',
                }}
              >
                HD
              </button>
              <Hemodialise></Hemodialise>
            </div>
            <div id="ACV E AP" style={{ display: funcao < 3 ? 'flex' : 'none', flexDirection: 'row' }}>
              <div>
                <label
                  className="title2"
                  style={{
                    marginTop: 15,
                    fontSize: 14,
                    justifyContent: 'center',
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                  }}
                >
                  {window.innerWidth > 800 ? 'APARELHO CARDIOVASCULAR:' : 'ACV:'}
                </label>
                <textarea
                  className="textarea"
                  autoComplete="off"
                  placeholder="APARELHO CARDIOVASCULAR."
                  title="APARELHO CARDIOVASCULAR."
                  defaultValue={acv}
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'ACV.')}
                  style={{
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                    height: 80,
                    marginRight: window.innerWidth > 800 ? 10 : 2.5,
                  }}
                  type="text"
                  id="inputAcv"
                  maxLength={50}
                ></textarea>
              </div>
              <div>
                <label
                  className="title2"
                  style={{
                    marginTop: 15,
                    fontSize: 14,
                    justifyContent: 'center',
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                  }}
                >
                  {window.innerWidth > 800 ? 'APARELHO RESPIRATÓRIO:' : 'AR:'}
                </label>
                <textarea
                  className="textarea"
                  autoComplete="off"
                  placeholder="APARELHO RESPIRATÓRIO."
                  title="APARELHO RESPIRATÓRIO."
                  defaultValue={ar}
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'AR.')}
                  style={{
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                    height: 80,
                  }}
                  type="text"
                  id="inputAr"
                  maxLength={50}
                ></textarea>
              </div>
            </div>
            <div id="ABDOME E OUTROS" style={{ display: funcao < 3 ? 'flex' : 'none', flexDirection: 'row', marginBottom: 5 }}>
              <div>
                <label
                  className="title2"
                  style={{
                    marginTop: 15,
                    fontSize: 14,
                    justifyContent: 'center',
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                  }}
                >
                  ABDOME:
                </label>
                <textarea
                  className="textarea"
                  autoComplete="off"
                  placeholder="ABDOME."
                  title="ABDOME."
                  defaultValue={abdome}
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'ABDOME.')}
                  style={{
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                    height: 80,
                    marginRight: window.innerWidth > 800 ? 10 : 2.5,
                  }}
                  type="text"
                  id="inputAbdome"
                  maxLength={50}
                ></textarea>
              </div>
              <div>
                <label
                  className="title2"
                  style={{
                    marginTop: 15,
                    fontSize: 14,
                    justifyContent: 'center',
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                  }}
                >
                  OUTROS:
                </label>
                <textarea
                  className="textarea"
                  autoComplete="off"
                  placeholder="OUTROS."
                  title="OUTROS DADOS CLÍNICOS IMPORTANTES."
                  defaultValue={outros}
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'OUTROS.')}
                  style={{
                    width: window.innerWidth > 800 ? 0.2 * window.innerWidth : 120,
                    height: 80,
                  }}
                  type="text"
                  id="inputOutros"
                  maxLength={50}
                ></textarea>
              </div>
            </div>
          </div>
          <div
            style={{
              display: 'flex',
              flexDirection: 'row',
              marginTop: 25,
              marginBottom: 0,
            }}
          >
            <button className="red-button" onClick={() => setviewcomponent(0)}>
              <img
                alt=""
                src={deletar}
                style={{
                  margin: 10,
                  height: 30,
                  width: 30,
                }}
              ></img>
            </button>
            <button className="green-button"
              onClick={() => updateData()}
              onMouseOver={() => poop == '' ? toast(1, '#ec7063', 'FAVOR INFORMAR EVACUAÇÃO.', 3000) : null}
            >
              <img
                alt=""
                src={salvar}
                style={{
                  margin: 10,
                  height: 30,
                  width: 30,
                }}
              ></img>
            </button>
          </div>
        </div>
      </div>
    );
  } else {
    return null;
  }
}
export default Evolucao;
