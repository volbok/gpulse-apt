/* eslint eqeqeq: "off" */
import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import deletar from '../images/deletar.svg';
import save from '../images/salvar.svg';
import Toast from './Toast';
import { useHistory } from "react-router-dom";
import DatePicker from '../components/DatePicker';
import Context from '../Context';

function Problemas(
  {
    viewproblema,
    inicio,
    idproblema,
    problema,
  }) {
  //servidor.
  var html = 'https://pulsarapp-server.herokuapp.com';
  // api para CID10:
  const {
    idatendimento,
    idpaciente,
    setpickdate1,
    pickdate1,
    nomeusuario
  } = useContext(Context)
  // history (react-router-dom).
  let history = useHistory()

  // chave para exibição do componente.
  const [viewcomponent, setviewcomponent] = useState(viewproblema);

  useEffect(() => {
    if (viewproblema !== 0) {
      setvalordatepicker(0);
      setviewcomponent(viewproblema);
      if (viewproblema == 1) {
        setpickdate1('');
      } else {
        setpickdate1(inicio);
      }
    } else {
    }
  }, [viewproblema])

  // inserindo registro.
  const insertData = () => {
    var problema = document.getElementById("inputProblema").value.toUpperCase();
    if (pickdate1 != '' && problema != '') {
      var obj = {
        inicio: pickdate1,
        idatendimento: idatendimento,
        problema: problema,
        usuario: nomeusuario,
      };
      axios.post(html + '/insertproblema', obj).then(() => {
        toast(1, '#52be80', 'PROBLEMA REGISTRADO COM SUCESSO.', 3000);
        setTimeout(() => {
          fechar();
        }, 3000);
      });
    } else {
      toast(1, '#ec7063', 'CAMPOS OBRIGATÓRIOS EM BRANCO.', 6000);
    }
  };

  // atualizando registro.
  const updateData = () => {
    var problema = document.getElementById("inputProblema").value.toUpperCase();
    if (inicio != '' && problema != '') {
      var obj = {
        inicio: pickdate1,
        idatendimento: idatendimento,
        problema: problema,
        usuario: nomeusuario,
      };
      axios.post(html + '/updateproblema/' + idproblema, obj).then(() => {
        toast(1, '#52be80', 'PROBLEMA ATUALIZADO COM SUCESSO.', 3000);
        setTimeout(() => {
          fechar();
        }, 3000);
      });
    } else {
      toast(1, '#ec7063', 'CAMPOS OBRIGATÓRIOS EM BRANCO.', 6000);
    }
  };

  // exibição do datepicker.
  const [valordatepicker, setvalordatepicker] = useState(0);
  const [mododatepicker, setmododatepicker] = useState(0);
  const showDatePicker = (value, mode) => {
    setvalordatepicker(0);
    setTimeout(() => {
      setvalordatepicker(value);
      setmododatepicker(mode);
    }, 500);
  }

  // função para construção dos toasts.
  const [valortoast, setvalortoast] = useState(0);
  const [cor, setcor] = useState('transparent');
  const [mensagem, setmensagem] = useState('');
  const [tempo, settempo] = useState(2000);
  const toast = (value, color, message, time) => {
    setvalortoast(value);
    setcor(color);
    setmensagem(message);
    settempo(time);
    setTimeout(() => {
      setvalortoast(0);
    }, time);
  }

  const salvar = () => {
    if (viewcomponent == 1) {
      insertData();
    } else if (viewcomponent == 2) {
      updateData();
    } else {
    }
  }

  const fechar = () => {
    setviewcomponent(0);
    window.scrollTo(0, 0);
    document.body.style.overflow = null;
    history.push('/refresh')
    history.push('/prontuario')
  }

  // renderização do componente.
  if (viewcomponent === 1) { // inserir.
    return (
      <div className="menucover fade-in" style={{ zIndex: 9, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
        <DatePicker valordatepicker={valordatepicker} mododatepicker={mododatepicker} />
        <Toast valortoast={valortoast} cor={cor} mensagem={mensagem} tempo={tempo} />
        <div className="menucontainer">
          <label className="title2" style={{ marginTop: 0, fontSize: 16 }}>
            INSERIR PROBLEMA
          </label>
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              width: '100%',
            }}
          >
            <div id="INÍCIO DO PROBLEMA" style={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', marginBottom: window.innerWidth > 800 ? 0 : 5 }}>
              <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <label className="title2" style={{ marginTop: 15, fontSize: 14 }}>
                  INÍCIO:
                </label>
                <label
                  autoComplete="off"
                  className="input"
                  placeholder="INÍCIO"
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'INÍCIO')}
                  title="INICIO."
                  onClick={() => showDatePicker(1, 1)}
                  defaultValue={''}
                  style={{
                    width: window.innerWidth > 800 ? 150 : 75,
                  }}
                  type="text"
                  maxLength={5}
                  id="inputInicio"
                >
                  {pickdate1}
                </label>
              </div>
            </div>
            <div id="PROBLEMA" style={{ display: 'flex', flexDirection: window.innerWidth > 800 ? 'row' : 'column', justifyContent: 'center' }}>
              <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <label className="title2" style={{ marginTop: 15, fontSize: 14 }}>
                  PROBLEMA:
                </label>
                <textarea
                  autoComplete="off"
                  className="textarea"
                  placeholder="PROBLEMA..."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'PROBLEMA...')}
                  title="PROBLEMA."
                  style={{
                    width: window.innerWidth > 800 ? 500 : 260, padding: 10,
                  }}
                  type="text"
                  maxLength={200}
                  id="inputProblema"
                ></textarea>
              </div>
            </div>
          </div>
          <div
            style={{
              display: 'flex',
              flexDirection: 'row',
              marginTop: 25,
              marginBottom: 0,
            }}
          >
            <button className="red-button" onClick={() => fechar()}>
              <img
                alt=""
                src={deletar}
                style={{
                  margin: 10,
                  height: 30,
                  width: 30,
                }}
              ></img>
            </button>
            <button className="green-button" onClick={() => salvar()}>
              <img
                alt=""
                src={save}
                style={{
                  margin: 10,
                  height: 30,
                  width: 30,
                }}
              ></img>
            </button>
          </div>
        </div>
      </div>
    );
  } else if (viewcomponent === 2) { // atualizar.
    return (
      <div className="menucover fade-in" style={{ zIndex: 9, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
        <DatePicker valordatepicker={valordatepicker} mododatepicker={mododatepicker} />
        <Toast valortoast={valortoast} cor={cor} mensagem={mensagem} tempo={tempo} />
        <div className="menucontainer">
          <label className="title2" style={{ marginTop: 0, fontSize: 16 }}>
            ATUALIZAR PROBLEMA
          </label>
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              width: '100%',
            }}
          >
            <div id="INÍCIO DO PROBLEMA" style={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', marginBottom: window.innerWidth > 800 ? 0 : 5 }}>
              <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <label className="title2" style={{ marginTop: 15, fontSize: 14 }}>
                  INÍCIO:
                </label>
                <label
                  autoComplete="off"
                  className="input"
                  placeholder="INÍCIO"
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'INÍCIO')}
                  title="INICIO."
                  onClick={() => showDatePicker(1, 1)}
                  defaultValue={inicio}
                  style={{
                    width: window.innerWidth > 800 ? 150 : 75,
                  }}
                  type="text"
                  maxLength={5}
                  id="inputInicio"
                >
                  {pickdate1}
                </label>
              </div>
            </div>
            <div id="PROBLEMA" style={{ display: 'flex', flexDirection: window.innerWidth > 800 ? 'row' : 'column', justifyContent: 'center' }}>
              <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <label className="title2" style={{ marginTop: 15, fontSize: 14 }}>
                  PROBLEMA:
                </label>
                <textarea
                  autoComplete="off"
                  className="textarea"
                  placeholder="PROBLEMA..."
                  onFocus={(e) => (e.target.placeholder = '')}
                  onBlur={(e) => (e.target.placeholder = 'PROBLEMA...')}
                  title="PROBLEMA."
                  defaultValue={problema}
                  style={{
                    width: window.innerWidth > 800 ? 500 : 260, padding: 10,
                  }}
                  type="text"
                  maxLength={200}
                  id="inputProblema"
                ></textarea>
              </div>
            </div>
          </div>
          <div
            style={{
              display: 'flex',
              flexDirection: 'row',
              marginTop: 25,
              marginBottom: 0,
            }}
          >
            <button className="red-button" onClick={() => fechar()}>
              <img
                alt=""
                src={deletar}
                style={{
                  margin: 10,
                  height: 30,
                  width: 30,
                }}
              ></img>
            </button>
            <button className="green-button" onClick={() => salvar()}>
              <img
                alt=""
                src={save}
                style={{
                  margin: 10,
                  height: 30,
                  width: 30,
                }}
              ></img>
            </button>
          </div>
        </div>
      </div>
    );
  } else {
    return null;
  }
}

export default Problemas;